from collections import OrderedDict

class Students:

    def __init__(self):
        self._students = OrderedDict()

    def add_students(self, *students):
        for student in students:
            if student not in self._students:
                self._students[student] = {}

    def remove_students(self, *students):
        for student in students:
            self._students.pop(student, None)

    def update_student(self, old_name, new_name):
        if old_name in self._students:
            self._students[new_name] = self._students.pop(old_name)

    def give_marks(self, student_name, subject, mark):
        if student_name in self._students:
            if subject not in self._students[student_name]:
                self._students[student_name][subject] = []
            self._students[student_name][subject].append(float(mark))

    def average_marks(self, student_name, subject):
        if student_name in self._students and subject in self._students[student_name]:
            marks = self._students[student_name][subject]
            return sum(marks) / len(marks) if marks else None
        return None

    def students(self):
        return list(self._students.keys())  # Kolejność zostaje zachowana
