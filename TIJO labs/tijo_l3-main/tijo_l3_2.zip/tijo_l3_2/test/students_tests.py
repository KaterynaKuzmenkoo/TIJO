import unittest
from src.students import Students

class TestStudents(unittest.TestCase):
    def test_add_students_should_add_students_to_list(self):
        # given
        student_list = Students()

        # when
        student_list.add_students("Bob Ross", "Anna Wintour")

        # then
        self.assertEqual(student_list.students(), ["Bob Ross", "Anna Wintour"])

    def test_remove_students_should_remove_students_from_list(self):
        # given
        student_list = Students()

        # when
        student_list.add_students("Bob Ross", "Anna Wintour")
        student_list.remove_students("Bob Ross")

        # then
        self.assertEqual(student_list.students(), ["Anna Wintour"])

    def test_update_students_should_update_students_in_list(self):
        # given
        student_list = Students()

        # when
        student_list.add_students("Bob Ross", "Anna Wintour")
        student_list.update_student("Bob Ross", "Alex Moor")

        # then
        self.assertEqual(sorted(student_list.students()), sorted(["Alex Moor", "Anna Wintour"]))


    def test_give_marks_to_students_should_give_marks_to_students(self):
        # given
        student_list = Students()

        # when
        student_list.add_students("Anna Wintour")
        student_list.give_marks("Anna Wintour", "Matematyka", 5.0)

        # then
        self.assertEqual(student_list.average_marks("Anna Wintour", "Matematyka"), 5.0)

    def test_average_marks_should_return_average_marks(self):
        # given
        student_list = Students()

        # when
        student_list.add_students("Anna Wintour")
        student_list.give_marks("Anna Wintour", "Matematyka", 5.0)
        student_list.give_marks("Anna Wintour", "Matematyka", 3.0)
        student_list.give_marks("Anna Wintour", "Historia", 4.0)

        avg_math = student_list.average_marks("Anna Wintour", "Matematyka")
        avg_history = student_list.average_marks("Anna Wintour", "Historia")
        avg_english = student_list.average_marks("Anna Wintour", "Angielski")

        # then
        self.assertEqual(avg_math, 4.0)
        self.assertEqual(avg_history, 4.0)
        self.assertIsNone(avg_english)

if __name__ == '__main__':
    unittest.main()
