import unittest

from src.task_list import TaskList

class TaskListTestCase(unittest.TestCase):
    def test_add_task_should_add_task_to_list(self):
        #given
        task_list = TaskList()

        #when
        task_list.add_task("Buy milk")

        #then
        self.assertEqual(task_list.tasks(), ["Buy milk"])

    def test_remove_task_should_remove_task_from_list(self):
        #given
        task_list = TaskList()

        #when
        task_list.add_task("Buy milk")
        task_list.remove_task("Buy milk")

        #then
        self.assertEqual(task_list.tasks(),[])

    def test_add_many_tasks_should_add_many_tasks_to_list(self):
        #given
        task_list = TaskList()

        #when
        task_list.add_tasks("Buy milk","Buy apple")

        #then
        self.assertEqual(task_list.tasks(),["Buy milk","Buy apple"])

if __name__ == '__main__':
    unittest.main()